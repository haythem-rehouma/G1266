### Download trained weights from [here](https://www.dropbox.com/s/nm76nw0w0ymky9g/model.h5?dl=0) and save it to this folder.
